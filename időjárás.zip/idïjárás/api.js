var inputval = document.querySelector('#cityinput')
var btn = document.querySelector('#add');
var city = document.querySelector('#cityoutput')
var descrip = document.querySelector('#description')
var temp = document.querySelector('#temp')
var wind = document.querySelector('#wind')
var magyar = document.querySelector('#magyar')
apik = "3045dd712ffe6e702e3245525ac7fa38"
function convertion(val)
{
    return (val - 273).toFixed(2)
}

btn.addEventListener('click', function()
{
  fetch('https://api.openweathermap.org/data/2.5/weather?q='+inputval.value+'&appid='+apik)
  .then(res => res.json())


  .then(data => 
  {
    var nameval = data['name']
    var descrip = data['weather']['0']['description']
    var tempature = data['main']['temp']
    var wndspd = data['wind']['speed']
    city.innerHTML=`Időjárás: <span>${nameval}<span>`
    temp.innerHTML = `Hőmérséklet': <span>${ convertion(tempature)} C</span>`
    description.innerHTML = `Felhő tartalom: <span>${descrip}<span>`
    wind.innerHTML = `Szélsebesség: <span>${wndspd} km/h<span>`
    magyar.innerHTML = `<b>Előre menjünk, ne hátra!</b>`

  })

  .catch(err => alert('Rosszul adta meg a város nevét! '))
})